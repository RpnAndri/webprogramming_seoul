document.onload(
    alert("Welcome to the online book store!")
);

function clicked() {
    alert("Submitted!");
}